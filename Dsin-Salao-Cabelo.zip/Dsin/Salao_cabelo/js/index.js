const d = new Date();
document.getElementById('demo').innerHTML = 'Website ' + d.getFullYear() + ' ';